import Foundation

enum AppVersion {
    static let current = "dev"
}
